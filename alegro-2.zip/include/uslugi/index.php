
    <!-- Main Content -->
    <div class="container">
        <div class="row">
            <div class="col-xs-12 content-head">
                <h1>Центр перекладів та легалізації <span class="light">"АЛЛЕГРО"</span></h1>
                <p class="affter-head">забезпечує професійну мовну підтримку наших клієнтів 33-ма мовами світу.<br />  
Наші найвищі цінності: якість,  оперативність та зручність.</p>
            </div>
        </div>
 </div>
      <div class="container">  
<div class="row">
    
<div class="col-xs-12 uslugi-head">
    <h2 class="uslugi">НАШ ЦЕНТР НАДАЄ ПОСЛУГИ</h2>
</div>
</div>

<!-- Uslugi End -->
<div class="row">
	<div class="col-sm-6">
		<ul> UA
<li style="color: green;"> <a href="/akredytovanyj-pereklad" style="color: green;">Акредитований переклад</a> </li>
<li style="color: green;"> <a style="color: green;" href="/apostyl">Апостиль</a></li>
<li style="color: green;"> <a href="/vytrebuvannja-dokumentiv" style="color: green;">Витребування документів</a> </li>
<li style="color: green;"> <a href="/zasvidchennja-dokumentiv-v-posolstvi" style="color: green;">Засвідчення документів в посольстві</a> </li>
<li style="color: green;"> <a href="/zasivdchennja-dokumentiv-v-tppu" style="color: green;">Засівдчення документів в ТППУ</a> </li>
<li style="color: green;"> <a href="/konsulska-legalizacija" style="color: green;">Консульська легалізація</a> </li>
<li style="color: green;"> <a style="color: green;" href="/kurjerska-dostavka">Курьєрська доставка</a> </li>
<li style="color: green;"> <a style="color: green;" href="/legalizacija">Легалізація</a> </li>
<li style="color: green;"> <a style="color: green;" href="/legalizacija-dokumentiv-v-zags">Легалізація документів в ЗАГС</a> </li>
<li style="color: green;"> <a style="color: green;" href="/legalizacija-spravok-pro-nesudymist">Легалізація справок про несудимість</a> </li>
<li style="color: green;"> <a style="color: green;" href="/nostryfikacija-dyploma-v-mon">Нострифікація диплома в МОН</a> </li>
<li style="color: green;"> <a style="color: green;" href="/notarialne-zavirennja-dyplomiv">Нотаріальне завірення дипломів</a> </li>
<li style="color: green;"> <a style="color: green;" href="/pereklad-sajtiv">Переклад сайтів</a> </li>
<li style="color: green;"> <a style="color: green;" href="/pysmovyj-pereklad">Письмовий переклад</a> </li>
<li style="color: green;"> <a style="color: green;" href="/prysjazhnyj-perekladach">Присяжний перекладач</a> </li>
<li style="color: green;"> <a style="color: green;" href="/usnyj-pereklad">Усний переклад</a> </li>
				</ul>
	</div>
</div>


</div>